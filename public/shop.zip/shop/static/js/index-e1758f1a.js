import{r as e}from"./index-4e0f3baf.js";let s={base:(s,o)=>e._post("/shop/index/base",s,o),getCount:(s,o)=>e._post("/shop/Index/index",s,o)};export{s as I};
