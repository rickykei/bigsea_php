var o={foo:{}},_=Object,t=function(){return{__proto__:o}.foo===o.foo&&!({__proto__:null}instanceof _)};export{t as h};
