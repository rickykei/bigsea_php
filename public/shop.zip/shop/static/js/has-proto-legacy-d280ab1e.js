System.register([],(function(o,t){"use strict";return{execute:function(){var t={foo:{}},e=Object;o("h",(function(){return{__proto__:t}.foo===t.foo&&!({__proto__:null}instanceof e)}))}}}));
