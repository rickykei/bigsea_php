import{f as o}from"./function-bind-72d06d3b.js";var t=o.call(Function.call,Object.prototype.hasOwnProperty);export{t as s};
